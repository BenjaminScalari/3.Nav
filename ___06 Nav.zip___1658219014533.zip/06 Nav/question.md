Starting from the navbar you created in the HTML exercise number 10, add the CSS properties. The Search button should have a hover effect (background green and white text). Make it responsive: starting from 768 pixel hide all the elements except "Navbar" and a hamburger menu, without fucntionality, should appear.

**Suggestion**:
The hamburger menu has `display: none` as starting property.
